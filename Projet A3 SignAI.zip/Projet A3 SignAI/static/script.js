function setTheme(theme) {
    document.body.className = theme + '-mode';
}
